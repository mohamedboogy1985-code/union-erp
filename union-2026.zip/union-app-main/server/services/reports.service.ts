import {
  GeneralLedgerReportItem,
  IncomeExpenseReport,
  ReceiptsPaymentsItem,
  SubledgerPartyStatement,
  SubledgerStatementItem,
  TrialBalanceItem,
} from '../../src/types/erp.js';
import { erpStore } from '../db/store.js';

export interface ReportFilterDto {
  organizationId?: string;
  startDate?: string;
  endDate?: string;
  includeDrafts?: boolean;
}

export class ReportsService {
  /**
   * 1. Subledger Detailed Statement of Account for a Specific Party (e.g., in 1301 Miscellaneous Debtors)
   * With Running Cumulative Balance calculation (الرصيد المتراكم بعد كل حركة)
   */
  public getSubledgerPartyStatement(
    partyId: string,
    filters: ReportFilterDto = {}
  ): SubledgerPartyStatement {
    const party = erpStore.subledgerParties.find((p) => p.id === partyId || p.partyCode === partyId);
    if (!party) {
      throw new Error(`حساب الأستاذ المساعد غير موجود برقم المعرف [${partyId}].`);
    }

    // Filter posted entries containing lines for this party
    const relevantEntries = erpStore.journalEntries
      .filter((entry) => {
        if (!filters.includeDrafts && entry.status !== 'POSTED') return false;
        if (filters.organizationId && entry.organizationId !== filters.organizationId) return false;
        if (filters.startDate && entry.date < filters.startDate) return false;
        if (filters.endDate && entry.date > filters.endDate) return false;
        return true;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let runningBalance = 0;
    let totalDebit = 0;
    let totalCredit = 0;

    const items: SubledgerStatementItem[] = [];

    for (const entry of relevantEntries) {
      const partyLines = entry.lines.filter((line) => line.subledgerPartyId === party.id);
      for (const line of partyLines) {
        totalDebit += line.debit;
        totalCredit += line.credit;

        // Debit increases the party receivable balance, Credit decreases it
        runningBalance += line.debit - line.credit;

        items.push({
          id: line.id,
          date: entry.date,
          entryNumber: entry.entryNumber,
          sourceDocumentRef: entry.sourceDocumentId || entry.sourceDocumentType,
          description: line.description || entry.description,
          debit: line.debit,
          credit: line.credit,
          runningBalance: Math.round(runningBalance * 100) / 100,
          journalEntryId: entry.id,
        });
      }
    }

    return {
      party,
      openingBalance: 0,
      totalDebit: Math.round(totalDebit * 100) / 100,
      totalCredit: Math.round(totalCredit * 100) / 100,
      closingBalance: Math.round(runningBalance * 100) / 100,
      items,
    };
  }

  /**
   * 2. General Ledger Report (الأستاذ العام)
   */
  public getGeneralLedger(filters: ReportFilterDto = {}): GeneralLedgerReportItem[] {
    const leafAccounts = erpStore.accounts.filter((a) => !a.isParent);
    const result: GeneralLedgerReportItem[] = [];

    const validEntries = erpStore.journalEntries.filter((entry) => {
      if (!filters.includeDrafts && entry.status !== 'POSTED') return false;
      if (filters.organizationId && entry.organizationId !== filters.organizationId) return false;
      if (filters.startDate && entry.date < filters.startDate) return false;
      if (filters.endDate && entry.date > filters.endDate) return false;
      return true;
    });

    for (const acc of leafAccounts) {
      let debitSum = 0;
      let creditSum = 0;
      let count = 0;

      for (const entry of validEntries) {
        const lines = entry.lines.filter((l) => l.accountId === acc.id);
        for (const line of lines) {
          debitSum += line.debit;
          creditSum += line.credit;
          count++;
        }
      }

      const closing =
        acc.nature === 'DEBIT' ? debitSum - creditSum : creditSum - debitSum;

      result.push({
        accountId: acc.id,
        accountCode: acc.code,
        accountName: acc.name,
        openingBalance: 0,
        totalDebit: Math.round(debitSum * 100) / 100,
        totalCredit: Math.round(creditSum * 100) / 100,
        closingBalance: Math.round(closing * 100) / 100,
        entriesCount: count,
      });
    }

    return result.sort((a, b) => a.accountCode.localeCompare(b.accountCode, undefined, { numeric: true }));
  }

  /**
   * 3. Receipts and Payments Statement (ميزان المقبوضات والمدفوعات)
   */
  public getReceiptsPaymentsStatement(filters: ReportFilterDto = {}): {
    items: ReceiptsPaymentsItem[];
    totalReceipts: number;
    totalPayments: number;
    netCashFlow: number;
  } {
    // Look at Cash & Bank accounts (Code starting with 110)
    const cashBankAccIds = erpStore.accounts
      .filter((a) => a.code.startsWith('110'))
      .map((a) => a.id);

    const validEntries = erpStore.journalEntries
      .filter((entry) => {
        if (!filters.includeDrafts && entry.status !== 'POSTED') return false;
        if (filters.organizationId && entry.organizationId !== filters.organizationId) return false;
        if (filters.startDate && entry.date < filters.startDate) return false;
        if (filters.endDate && entry.date > filters.endDate) return false;
        return true;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let runningCash = 0;
    let totalReceipts = 0;
    let totalPayments = 0;
    const items: ReceiptsPaymentsItem[] = [];

    for (const entry of validEntries) {
      const cashLines = entry.lines.filter((l) => cashBankAccIds.includes(l.accountId));
      for (const cl of cashLines) {
        const isReceipt = cl.debit > 0;
        const rAmount = cl.debit;
        const pAmount = cl.credit;

        totalReceipts += rAmount;
        totalPayments += pAmount;
        runningCash += rAmount - pAmount;

        // Find counterparty
        const counterLine = entry.lines.find((l) => l.id !== cl.id);

        items.push({
          date: entry.date,
          documentNumber: entry.entryNumber,
          description: entry.description,
          accountName: cl.accountName,
          partyName: counterLine?.subledgerPartyName || counterLine?.accountName,
          receiptAmount: Math.round(rAmount * 100) / 100,
          paymentAmount: Math.round(pAmount * 100) / 100,
          runningCashBalance: Math.round(runningCash * 100) / 100,
        });
      }
    }

    return {
      items,
      totalReceipts: Math.round(totalReceipts * 100) / 100,
      totalPayments: Math.round(totalPayments * 100) / 100,
      netCashFlow: Math.round((totalReceipts - totalPayments) * 100) / 100,
    };
  }

  /**
   * 4. Income & Expense Report (حساب الإيرادات والمصروفات)
   */
  public getIncomeExpenseReport(filters: ReportFilterDto = {}): IncomeExpenseReport {
    const revenueAccs = erpStore.accounts.filter((a) => a.type === 'REVENUE' && !a.isParent);
    const expenseAccs = erpStore.accounts.filter((a) => a.type === 'EXPENSE' && !a.isParent);

    const validEntries = erpStore.journalEntries.filter((entry) => {
      if (!filters.includeDrafts && entry.status !== 'POSTED') return false;
      if (filters.organizationId && entry.organizationId !== filters.organizationId) return false;
      if (filters.startDate && entry.date < filters.startDate) return false;
      if (filters.endDate && entry.date > filters.endDate) return false;
      return true;
    });

    const revenues = revenueAccs.map((acc) => {
      let sum = 0;
      for (const entry of validEntries) {
        for (const line of entry.lines) {
          if (line.accountId === acc.id) {
            sum += line.credit - line.debit;
          }
        }
      }
      return {
        accountId: acc.id,
        accountCode: acc.code,
        accountName: acc.name,
        amount: Math.round(sum * 100) / 100,
      };
    });

    const expenses = expenseAccs.map((acc) => {
      let sum = 0;
      for (const entry of validEntries) {
        for (const line of entry.lines) {
          if (line.accountId === acc.id) {
            sum += line.debit - line.credit;
          }
        }
      }
      return {
        accountId: acc.id,
        accountCode: acc.code,
        accountName: acc.name,
        amount: Math.round(sum * 100) / 100,
      };
    });

    const totalRevenues = revenues.reduce((acc, r) => acc + r.amount, 0);
    const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);

    return {
      revenues,
      expenses,
      totalRevenues: Math.round(totalRevenues * 100) / 100,
      totalExpenses: Math.round(totalExpenses * 100) / 100,
      netSurplusOrDeficit: Math.round((totalRevenues - totalExpenses) * 100) / 100,
    };
  }

  /**
   * 5. Trial Balance (ميزان المراجعة بالمجاميع والأرصدة)
   */
  public getTrialBalance(filters: ReportFilterDto = {}): {
    items: TrialBalanceItem[];
    totals: {
      periodDebit: number;
      periodCredit: number;
      closingDebit: number;
      closingCredit: number;
    };
  } {
    const leafAccounts = erpStore.accounts.filter((a) => !a.isParent);
    const items: TrialBalanceItem[] = [];

    const validEntries = erpStore.journalEntries.filter((entry) => {
      if (!filters.includeDrafts && entry.status !== 'POSTED') return false;
      if (filters.organizationId && entry.organizationId !== filters.organizationId) return false;
      if (filters.startDate && entry.date < filters.startDate) return false;
      if (filters.endDate && entry.date > filters.endDate) return false;
      return true;
    });

    let totalPeriodDebit = 0;
    let totalPeriodCredit = 0;
    let totalClosingDebit = 0;
    let totalClosingCredit = 0;

    for (const acc of leafAccounts) {
      let periodDebit = 0;
      let periodCredit = 0;

      for (const entry of validEntries) {
        for (const line of entry.lines) {
          if (line.accountId === acc.id) {
            periodDebit += line.debit;
            periodCredit += line.credit;
          }
        }
      }

      totalPeriodDebit += periodDebit;
      totalPeriodCredit += periodCredit;

      let closingDebit = 0;
      let closingCredit = 0;

      if (acc.nature === 'DEBIT') {
        const net = periodDebit - periodCredit;
        if (net >= 0) closingDebit = net;
        else closingCredit = Math.abs(net);
      } else {
        const net = periodCredit - periodDebit;
        if (net >= 0) closingCredit = net;
        else closingDebit = Math.abs(net);
      }

      totalClosingDebit += closingDebit;
      totalClosingCredit += closingCredit;

      items.push({
        accountId: acc.id,
        accountCode: acc.code,
        accountName: acc.name,
        nature: acc.nature,
        openingDebit: 0,
        openingCredit: 0,
        periodDebit: Math.round(periodDebit * 100) / 100,
        periodCredit: Math.round(periodCredit * 100) / 100,
        totalDebit: Math.round(periodDebit * 100) / 100,
        totalCredit: Math.round(periodCredit * 100) / 100,
        closingDebit: Math.round(closingDebit * 100) / 100,
        closingCredit: Math.round(closingCredit * 100) / 100,
      });
    }

    return {
      items: items.sort((a, b) => a.accountCode.localeCompare(b.accountCode, undefined, { numeric: true })),
      totals: {
        periodDebit: Math.round(totalPeriodDebit * 100) / 100,
        periodCredit: Math.round(totalPeriodCredit * 100) / 100,
        closingDebit: Math.round(totalClosingDebit * 100) / 100,
        closingCredit: Math.round(totalClosingCredit * 100) / 100,
      },
    };
  }
}

export const reportsService = new ReportsService();
